function concat() {
  console.log(arguments);
}
