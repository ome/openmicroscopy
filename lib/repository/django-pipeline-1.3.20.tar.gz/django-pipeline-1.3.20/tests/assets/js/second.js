function cat() {
  console.log("hello world");
}
