.. _ref-using:

====================
Sites using Pipeline
====================

The following sites are a partial list of people using Pipeline.

Are you using pipeline and not being in this list? Drop us a line. 

20 Minutes
----------

For their internal tools: http://www.20minutes.fr

The Molly Project
-----------------

Molly is a framework for the rapid development of information and service
portals targeted at mobile internet devices: http://mollyproject.org

It powers the University of Oxford's mobile portal: http://m.ox.ac.uk/

Croisé dans le Métro
--------------------

For their main and mobile website:

* http://www.croisedanslemetro.com
* http://m.croisedanslemetro.com

Ulule
-----

For their main and forum website:

* http://www.ulule.com
* http://vox.ulule.com

Borsala
-------

Borsala is the social investment plaform. You can follow stock markets that are traded in Turkey:

http://borsala.com
