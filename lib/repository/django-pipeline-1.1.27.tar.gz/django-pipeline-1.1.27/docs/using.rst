.. _ref-using:

====================
Sites using Pipeline
====================

The following sites are a partial list of people using Pipeline.

Are you using pipeline and not being in this list ? Drop us a line. 

20 Minutes
----------

For their internal tools : http://www.20minutes.fr

Pitchfork
---------

For their main website : http://pitchfork.com

The Molly Project
-----------------

Molly is a framework for the rapid development of information and service
portals targeted at mobile internet devices : http://mollyproject.org

It powers the University of Oxford's mobile portal : http://m.ox.ac.uk/

Croisé dans le Métro
--------------------

For their main and mobile website :

* http://www.croisedanslemetro.com
* http://m.croisedanslemetro.com
